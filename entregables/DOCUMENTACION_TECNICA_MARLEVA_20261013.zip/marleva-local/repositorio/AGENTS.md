# Marleva: instrucciones del repositorio

Leer antes de cada proceso o cambio las instrucciones vigentes, las cuatro fuentes en ../../entregables/fuentes_finales/ y docs/proceso/PROCESO_DESARROLLO_MARLEVA.md. Aplicar el protocolo, nomenclatura y puertas documentales. Leer también docs/proceso/MATRIZ_CASOS_M1.md con estados, negativos, recuperación y pruebas; casos diseñados no equivalen a ejecutados. Inventariar/leer cambios; no afirmar lectura de resúmenes, dependencias o artefactos generados.

Documentación coherente y revisable antes del código: caso de uso, secuencia y pasos identificados, estados/errores, modelo DBML, DDL derivado y API OpenAPI YAML/Swagger. Cambios de pantallas parten del diagrama de secuencia y requieren revisión visual antes de implementación. Corregir primero el diagrama y sus contratos cuando una incidencia cambie el proceso.

API Nest modular por capas con controllers, DTOs, casos de uso, entidades/reglas de dominio, puertos, repositorios y adaptadores con responsabilidades reales. Cliente Expo separado y por módulo. No construir capas vacías ni llamar terminada a la separación actual pendiente de refactor.

Cada cambio de backend/frontend tiene pruebas unitarias y de integración para los casos necesarios; performance proporcional al cambio y regresión, con ambiente, dataset, métricas y límites. Organizar tests en unit/integration/performance, backend/frontend y módulo; resultados en tests/results. No declarar calidad, cobertura, rendimiento o cumplimiento sin evidencia.

Instalaciones oficiales verificadas, versiones/lockfiles/imágenes fijados, licencias/permisos resueltos, configuración homogénea y arranque/parada/recuperación documentados. No usar runtime Codex como instalación propia. Sin secretos/datos reales en Git o resultados; solo fixtures locales. A0 y SDKAndroid autorizados; no cuentas externas, gasto, publicación, contactos, cobros ni datos reales. No implementar M2–M10 completos durante base/M1.

Registro actual: MAR-CHAT-004, continúa abierto. Actualizar fuentes solo por cambios necesarios y releer finales antes de entregar. No tocar sources/ ni originales sincronizados. Los ejemplos DBML/YAML del usuario permanecen no recibidos hasta acceso comprobado.

Al entregar cambios, indicar nombres/versiones exactas para reemplazar Fuentes y texto de instrucciones para pegar; guardar localmente no acredita subida. No editar originales sincronizados para simularla.
