# Proceso de desarrollo y auditoría de Marleva

Versión 1.1. Fecha: 13-10-2026 America/Merida. MAR-CHAT-004 continúa abierto. Instrucción vigente del usuario: documentación revisable antes de desarrollo; pruebas para cada cambio de backend/frontend; instalaciones correctas, homogéneas y sin componentes sin identificar. No acredita implementación completa ni conformidad con estándares.

## Lectura obligatoria antes de cada proceso o cambio

1. Instrucciones vigentes del usuario y AGENTS.md aplicable.
2. [00 Guía](../../../../entregables/fuentes_finales/00_GUIA_PRINCIPAL_MARLEVA.md), [01 Estado](../../../../entregables/fuentes_finales/01_ESTADO_Y_DECISIONES_MARLEVA.md), [02 Diseño](../../../../entregables/fuentes_finales/02_MVP1_ALCANCE_Y_DISENO_MARLEVA.md), [03 Evidencia](../../../../entregables/fuentes_finales/03_REFERENTES_Y_EVIDENCIA_MARLEVA.md).
3. Este documento; registro de procesos/casos del módulo; diagramas afectados; modelo DBML y DDL; OpenAPI YAML; pruebas y resultados pertinentes.
4. Inventariar cambios y leer los archivos afectados completos. No usar una lista o búsqueda como lectura completa. No divulgar secretos ni declarar leídas dependencias/cachés/artefactos generados.

Si hay una contradicción entre diseño, diagrama, modelo, API o código, registrarla y corregir la documentación antes de implementar. Si falta una decisión material, detener únicamente el trabajo que depende de ella. Las autorizaciones previas de desarrollo/SDK se conservan; no autorizan publicación, datos reales o dinero real.

## Todas las observaciones del usuario y contraste real

| ID | Requisito/observación | Contraste con fuentes y archivos | Estado y salida necesaria |
|---|---|---|---|
| R01 | Saber dónde está el proyecto | 02 §16 A3 preveía marleva-local; ubicación actual marleva-local/repositorio | Reubicación hecha; rutas y arranque tras traslado por verificar |
| R02 | Carpeta específica para el repositorio | Antes no había .git; ahora existe .git local en repositorio | Sin remoto, commits o subida |
| R03 | Saber dónde está gitignore | Existe .gitignore en raíz del repositorio | Exclusiones de .env, claves, herramientas, dependencias, Prisma generado y APK comprobadas con git check-ignore; revisión completa de publicables pendiente |
| R04 | Instalaciones correctas y homologadas | 02 A1–A5/16.2; manifiesto y toolchain existentes | Herramientas verificadas parcialmente; reinstalación limpia y estado tras traslado pendientes |
| R05 | Documentación lista antes de desarrollar | 00 §7 y C08 ya lo exigían; 02 documental no reemplaza contratos/diagramas revisables | Se avanzó demasiado pronto; se detiene implementación para cerrar esta revisión |
| R06 | Lectura obligatoria del proceso e instrucciones | 00 y AGENTS exigían lectura de fuentes, faltaba protocolo técnico enlazado | Este documento y AGENTS del repo; texto de instrucciones para pegar actualizado |
| R07 | Enumerar y validar todo contra archivos | Fuentes 00/01/02/03, antecedentes y código propio | Esta matriz; inventario y límites de lectura; no afirmar auditoría exhaustiva de dependencias |
| R08 | Arquitectura explícita | C22 PostgreSQL, C23 Nest/TS, C24 Expo/TS, C07 separación | Arquitectura modular por capas concretada abajo; código actual aún no coincide |
| R09 | Separar back en controller/service/DTO/entity/repository | Hay controller.ts/account.service.ts, sin DTOs/repositorios por módulo | Refactor pendiente después de revisión documental; no crear capas vacías |
| R10 | Separación de carpetas del front y back | apps/client y apps/api existentes | Cliente deberá separarse por módulo, casos y componentes; pantalla monolítica actual pendiente |
| R11 | Pruebas unitarias en cada desarrollo | Simulador/configuración tienen pruebas; no toda lógica M1 ni cliente | tests/unit/backend y frontend; completar casos antes de cerrar cada cambio |
| R12 | Pruebas de integración por casos de uso | 13 pruebas en última corrida anterior, más recorrido Chrome | Reubicadas/separadas, IDs de11 integración backend y9 unitarias; faltan casos/plataformas de 02 §16.4 |
| R13 | Pensar como tester en back y front | 02 §14/16.4 ya contenían errores/permisos/recuperación | Éxito, negativos, límites, concurrencia, caídas, recuperación, accesibilidad y regresión |
| R14 | Pruebas de performance | No se habían ejecutado mediciones | Carpetas backend/frontend y plan medible; no inventar tiempos o capacidad |
| R15 | Carpetas para pruebas/resultados/casos | Antes pruebas API y evidencias mezcladas | Estructura por tipo/lado/módulo; resultados con fecha, ambiente y límites |
| R16 | Diagramas de secuencia por módulo | 02 tenía diagramas generales; no archivos por proceso M1 | docs/diagramas/secuencia/M1 y carpetas M2–M10; matrices de procesos; pendientes identificados |
| R17 | Modificar pantallas primero mediante secuencias | No se presentó esa trazabilidad antes de la interfaz | Secuencia/estado/API/prueba primero; propuesta visual y revisión después; no tratar colores actuales como aprobados |
| R18 | Nomenclatura para localizar errores y corregir el diagrama | IDs C/M/B existentes; faltaban IDs de UC/SEQ/STEP/TEST/BUG | Estándar abajo, IDs estables y tabla de trazabilidad |
| R19 | Carpeta de modelado de datos en DBML | Prisma + SQL existen, DBML ausente antes de este pedido | DBML M1 revisable y DDL exportado; alcance global futuro separado de esquema implementado |
| R20 | Abrir DBML en dbdiagram.io/d | Sintaxis/exportación oficiales comprobadas; ejemplos del usuario no recibidos | Archivo sin secretos para importar/pegar; no se publica ni crea cuenta por hacerlo local |
| R21 | DDL generado a partir del DBML | Migración 001 vacía y 002 SQL manual aplicada antes | Exportación DBML→DDL; comparación pendiente con esquema real; no reescribir migraciones aplicadas |
| R22 | APIs YAML documentadas con Swagger revisable | Existe OpenAPI3.1.1 JSON y tipos generados; no YAML/Swagger visible previo | YAML canónico M1, JSON/tipos/preview derivados; revisión antes de nuevas implementaciones |
| R23 | Usar ejemplos DBML/YAML enviados | No hay adjuntos accesibles en los mensajes recibidos | Pendientes; no reconstruidos ni afirmados leídos; adaptar cuando estén disponibles |
| R24 | Secuencia de chats y entrega de documentos | 001–003 cerrados; 004 abierto y autorizado. Fuentes no se actualizaron oportunamente durante ejecución | Corregir 01 y continuidad; no saltar a005 ni usar FIN mientras se ordena este tema |
| R25 | Entregar documentos accesibles y ubicación real | sources/ZIP siguen1.0; solo escrituras locales | Versiones finales enlazadas y releídas; carga compartida no realizada |

## Arquitectura y estándar de programación

Base confirmada: monolito modular NestJS/TypeScript con API REST; cliente universal Expo/React Native/TypeScript separado; PostgreSQL17 central; Prisma7 para persistencia. Supabase local provee identidad/archivos. No microservicios ni arquitectura privada de referentes inferida. Capas: transporte → aplicación → dominio; aplicación usa puertos de persistencia e integraciones que implementa infraestructura. No llamar implementada una arquitectura por dibujar sus carpetas.

| Carpeta por módulo backend | Responsabilidad | Prohibición |
|---|---|---|
| modules/m1/presentation/controllers | HTTP, entrada/salida y códigos de respuesta | SQL, decisiones de negocio o importes |
| modules/m1/presentation/dtos | DTO: estructura de solicitud/respuesta y validación de ejecución conforme OpenAPI | Aceptar roles/importes arbitrarios del cliente |
| modules/m1/application/use-cases | Un caso de uso por operación; coordina reglas, transacción y puertos | Depender de detalles HTTP/SDK en reglas |
| modules/m1/application/ports | Contratos concretos de repositorio, identidad y correo | Adaptador genérico vacío para todo motor |
| modules/m1/domain/entities | Identidad, estados e invariantes de cuenta/sesión/desafío | Confundir entidades de dominio con modelos ORM |
| modules/m1/domain/services | Reglas que afectan más de una entidad | Llamadas a proveedor o base |
| modules/m1/infrastructure/repositories | Prisma/PG y operaciones atómicas, sin filtrarse a controller | API accediendo tablas de otros módulos para saltar reglas |
| modules/m1/infrastructure/adapters | Supabase/SMTP detrás de puertos pequeños | service_role o refresh tokens en cliente |
| shared y config | Errores, validación, configuración y controles transversales con función real | Convertirse en contenedor de toda lógica |

Frontend: app/ mantiene rutas; src/modules/m1 separa pantallas, componentes, casos de uso y adaptadores API/sesión por plataforma. El contrato generado tipa solicitudes/respuestas; los tipos no sustituyen validación del servidor. Credencial móvil en SecureStore; web en cookie HttpOnly/Secure con origen/CSRF. No pantallas aisladas ni regla comercial confiada al cliente.

TypeScript estricto; nombres de código en inglés, mensajes de usuario en español; archivos con responsabilidad definida; DTOs formales, estado/errores explícitos, pruebas de límites y concurrencia. Fijar formato/lint y versiones compatibles antes del refactor. Inyección de dependencias de Nest; evitar any y Record genérico en contratos de negocio. Imports entre módulos por contratos públicos. Migraciones inmutables una vez aplicadas. Sin secretos/datos reales en Git/logs/resultados. No se acredita todavía cumplimiento de estos criterios por el código actual.

## Estructura obligatoria

```text
marleva-local/repositorio/
  .git/ .gitignore AGENTS.md README.md
  apps/api/                         API y módulos backend
  apps/client/                      cliente y módulos frontend
  packages/contracts/               tipos/JSON generados desde YAML
  packages/config/                  configuración común usada
  infra/local/                      herramientas, manifiesto, Supabase y secretos ignorados
  docs/proceso/                     este protocolo, auditoría, trazabilidad
  docs/diagramas/secuencia/M1..M10/  Mermaid por caso, con pasos estables
  docs/modelado-datos/dbml/          modelo fuente
  docs/modelado-datos/ddl/           SQL generado para revisión, no migración automática
  docs/apis/M1..M10/                 OpenAPI YAML y revisión Swagger
  tests/unit/backend|frontend/M1/   pruebas de unidades y reglas
  tests/integration/backend|frontend/M1/  recorridos y componentes reales
  tests/performance/backend|frontend/M1/  cargas, tiempos y métricas
  tests/fixtures/                   solo datos ficticios
  tests/results/                    actas/reportes; sin secretos
  scripts/                         generación, comprobación y operación
  artifacts/                       builds identificados, ignorados en Git
```

Las carpetas reservadas no acreditan contenido implementado. Todos los nuevos módulos siguen el mismo esquema, sin construir M2–M10 completos durante base/M1. Documentación funcional global sigue en02; este protocolo define cómo desarrollar y comprobarla.

## Nomenclatura y trazabilidad

| Artefacto | Formato | Ejemplo |
|---|---|---|
| Requisito de esta corrección | MAR-Rxx | MAR-R19 |
| Caso de uso | MAR-Mn-UC-xxx | MAR-M1-UC-001 |
| Secuencia | MAR-Mn-SEQ-xxx | MAR-M1-SEQ-001 |
| Paso estable del diagrama | Sxxx dentro de SEQ | MAR-M1-SEQ-001:S030 |
| Operación API | MAR_Mn_API_xxx | MAR_M1_API_001 |
| Pantalla | MAR-Mn-UI-xxx | MAR-M1-UI-001 |
| Prueba | MAR-Mn-UT/IT/PF-BE/FE-xxx | MAR-M1-IT-BE-001 |
| Incidencia | MAR-Mn-BUG-xxx | MAR-M1-BUG-001 |
| Modelo/DDL | MAR-Mn-DATA-xxx | MAR-M1-DATA-001 |

Cada incidencia indica caso, diagrama:paso, pantalla/API/campo, condición de reproducción, resultado esperado/real y prueba de regresión. No renumerar IDs por insertar pasos; usar espacios S010/S020/S030 y nuevas etiquetas. Corregir el diagrama primero, luego contrato/datos y código, finalmente la prueba. Una secuencia describe comunicaciones y decisiones; no sustituye estados, validaciones o revisión visual.

## Puertas antes y después de cada cambio

1. Leer, comprobar autorización y limitar el cambio al módulo/caso.
2. Registrar entradas, reglas, estados, actor, errores y recuperación. Relacionar UC→SEQ/paso→API→datos→pantalla→pruebas.
3. Revisar/actualizar Mermaid, DBML, DDL y OpenAPI YAML. Presentarlos para revisión. Una propuesta visual no se implementa sin revisión correspondiente.
4. Definir pruebas unitarias e integración necesarias para backend y frontend; performance proporcional al cambio y regresión. Definir condiciones/objetivos antes de medir.
5. Implementar solo después de coherencia documental. No crear clases, rutas o carpetas vacías como si fueran arquitectura terminada.
6. Generar artefactos desde fuentes: DBML→DDL; YAML→JSON/tipos/Swagger. Revisar diferencia y migración; no aplicar el DDL completo sobre una base existente.
7. Ejecutar pruebas; registrar ambiente/versión/dataset/comando/esperado/obtenido, fallos, corrección y límites. No usar tests que solo repiten el código o casillas sin evidencia.
8. Releer finales completos, validar enlaces/contratos/modelo, actualizar solo fuentes afectadas y entregar enlaces/ubicación/subida. Módulo incompleto continúa; chat abierto no se cierra por una duda.

## Plan de pruebas y performance

Unitarias backend: estados/transiciones, caducidad, cooldown, revocación, rol, límites de cambio de correo, cifrado con bibliotecas estándar, simulador. Frontend: validación, estados de carga/error, espera/reenvío, sesión vencida, navegación, adaptación web/nativo y prevención de doble envío. Integración backend: PG/Auth/SMTP reales locales, dos actores, concurrencia y caídas; frontend: cliente+API en Chrome/Safari y builds Android/iOS, con accesibilidad.

Performance backend: salud frente a cuenta autenticada, paginación de avisos, refrescos concurrentes, saturación/recuperación y límites de abuso. Dataset y sesiones ficticias preparadas; no medir límiteOTP como capacidad de negocio. Registrar concurrencia, duración, warmup, p50/p95/p99, solicitudes/s, errores, CPU/RAM y versiones. Frontend: carga, tamaño de bundle, tiempos de interacción/red, renders y memoria en dispositivo/viewport identificados. Chrome no acredita Safari ni dispositivo físico. Sin umbrales productivos aprobados: objetivos locales deben definirse como criterios de ingeniería revisables, separados de compromisos del piloto. No existen aún resultados de performance.

## Estado de auditoría y trabajo siguiente

Hechos anteriores al traslado:13 tests pasaron en última corrida; recorrido Chrome por HTTPS validado pasó; instalación frozen conservó hash; APK debug ARM64 inicial compiló e instaló. Recompilación posterior fue interrumpida: log no contiene cierre exitoso; no acreditarla. Android no completó recorrido: primer arranque falló por política de Metro, corregida documentalmente/en configuración pero todavía sin prueba final. iOS/Xcode no comprobados. Usuario instalará Xcode y aceptará licencia; solo iPhone físico disponible. Restablecimiento aislado, archivos privados, recuperación MFA, caídas/outbox y cobertura completa de02 §16.4 siguen pendientes. Las pruebas existentes no cubren estos faltantes.

Servicios de aplicación/Supabase/VM detenidos para esta revisión, con datos conservados. Autorización A0 y SDKAndroid vigente. Próximo paso: revisar matriz, procesos, DBML/DDL y YAML/Swagger; recibir ejemplos si existen; cerrar diferencias antes de refactor y de revisar diseño visual. No iniciar M2 ni declarar M1 completa. Chat004 conserva su ID; instrucciones/fuentes locales deben cargarse al proyecto compartido para otra conversación, lo cual no se ha realizado.


## Brechas verificadas en archivos propios y prioridad de corrección

| Incidencia | Evidencia actual | Corrección antes de declarar cumplimiento |
|---|---|---|
| MAR-M1-BUG-001 arquitectura | AccountService importa Prisma/Supabase y concentra casos; controller acepta Record; cliente api Promise<any> e index monolítico | Contratos/DTOs/puertos/casos/repositorios reales, separar cliente, fijar formato/lint; no módulos vacíos |
| MAR-M1-BUG-002 datos | EmailChange.accountId sin FK; roles boolean y estados text sin catálogo/check; Audit conservación incompleta | Diseñar relaciones/invariantes y migración revisable; comparar DBML/DDL/Prisma/DB |
| MAR-M1-BUG-003 generación SQL | DBML exporta FKs DEFERRABLE; SQL aplicado no. Exportado añade CREATE SCHEMA/comentarios, no GRANT/REVOKE | Diferencias no equivalentes; DDL revisión, no reemplazo automático de migraciones |
| MAR-M1-BUG-004 API | YAML errores repetidos genéricos, sin Health ni cabeceras Origin/native/CSRF/Retry-After/Set-Cookie detalladas; DTO runtime no valida additionalProperties | Completar contrato y pruebas de petición/respuesta con códigos específicos; no confundir parser con coherencia |
| MAR-M1-BUG-005 avisos | SEQ008:S080 dice paginada; código retorna50 y next_cursor:null | Documentar límite actual; diseñar cursor/estados/errores y probar antes de implementar |
| MAR-M1-BUG-006 recovery | MFA recuperación/revocación administrativa y Storage privado/restauración no completos | Cerrar casos16.4/B09/B12 sin transferir cuentas por comprobante vecinal |
| MAR-M1-BUG-007 sesiones/concurrencia | Cuotas/origen compartido, refresh lease/caídas/caducidades requieren más pruebas; Retry-After fijo60 | Casos de límites, concurrencia, caídas y reconciliación; tiempos reales consistentes |
| MAR-M1-BUG-008 prueba engañosa | Test nuevo/existente crea dos correos nuevos | Corregir fixture y probar cuenta existente de verdad; título no acredita caso |
| MAR-M1-BUG-009 móviles | Build Android posterior interrumpido; Xcode/iOS físicos no comprobados | Rehacer build/recorridos tras traslado, conservar pendientes físicos |
| MAR-M1-BUG-010 performance | Readiness crea/desconecta Prisma por llamada; ningún resultado de carga | Plan de casos autenticados y recursos, medir sin prometer capacidad |
| MAR-M1-BUG-011 entrega/continuidad | Fuentes quedaron desactualizadas durante ejecución | Fuentes locales corregidas, prompt004 continúa; subir versiones reales cuando corresponda |

Las secuencias están en revisión: describen comportamiento parcial y objetivo; leer estado y estas diferencias. Pruebas unitarias nuevas:9/9 pasaron; primera corridafrontend falló por resolver React Native Flow y se corrigieron mocks del entorno de tests. No prueba UI completa. Instalación frozen offline posterior al traslado pasó; no peer conflicts nuevos observados. No certificación de seguridad/arquitectura/estándares.

Estado fuera del repo identificado: perfil marleva/VM/volúmenes en ~/.colima, estado CLI en ~/.supabase, adb en ~/.android, CA pública de desarrollo confiada en llavero login. Herramientas/descargas/certificados privados y cachesGradle/AVD están bajo infra/local ignorado; no portabilidad total acreditada. Docker archive SHA local calculado no equivale a checksum remoto verificado. Actualizar manifiesto después de cerrar revisión y reiniciar autorizadamente, manteniendo la captura anterior como histórica.


## Continuación13-10-2026: documentación vinculada

Leer [matriz M1 de casos/estados/pruebas](MATRIZ_CASOS_M1.md) antes de cada proceso o cambio, con protocolos/diagramas/modelo/API. YAML0.2.0 describe14 operaciones parciales observadas, Health ycabeceras/condiciones, errores ybrechas. No se implementaron endpoints adicionales ni UI. SEQ008:S080 corregido a límite actual50/cursor null. DDL exportado ahora conserva NOT DEFERRABLE mediante transformación explícita; no aplica privilegios/bootstrap ni modifica DB. BUG003 corrección documental comprobable, cotejoDBviva pendiente; BUG004/005 coherencia descriptiva mejorada, runtime/contratoobjetivo pendientes. No cerrar BUG001/002/006–010 por estos documentos.

Fuentes e instrucciones se actualizan localmente; usuario debe reemplazar versiones compartidas y pegar instrucciones cuando se entreguen. No hay subida automática comprobada; sources/ZIPoriginal intactos. Pruebas≥100 son planes, umbralesperformance propuestos, no ejecución/aprobación comercial. Próximo: cerrar datos/roles/estados ycontratos de recuperación/Storage yramas de fallos, después refactor/pruebas autorizadas. El código de negocio ypantallas siguen detenidos.
