# Modelo de datos M1, en revisión

Fuente: [DBML](dbml/MAR-M1-DATA-001.dbml). Exportación: [DDL PostgreSQL](ddl/MAR-M1-DATA-001.sql). Copiar/importar el DBML en https://dbdiagram.io/d; sin credenciales ni datos reales. Parser/exportador local @dbml/core10.3.1 aceptó el archivo; no se subió ni abrió en una cuenta externa.

Comparación estática con Prisma y migración002: ocho tablas, campos, defaults, uniques, tres índices y dos FKs existentes. DBML conserva las brechas físicas para no inventar integridad implementada. Exportación no equivale exactamente al SQL aplicado: crea esquema/comentarios, FKs ahora NOT DEFERRABLE por transformación explícita del generador, concordantes con SQL aplicado; omite GRANT/REVOKE/bootstrap. Prisma relaciones usan defaults de referencialidad que también deben explicitarse y contrastarse. DB viva no comparada en esta revisión porque servicios detenidos. No reescribir001/002 aplicadas ni aplicarDDL íntegro a base existente.

Faltan modelo objetivo de roles/estados/invariantes, FKEmailChange y política de Audit/retención; verBUG002/003 del protocolo. DBMLM1 no constituye modelo completo M2–M10; Auth/Storage administrados por proveedor no se recrean. Generar con pnpm docs:generate; revisión de diferencias antes de migración futura.

13-10-2026: corregido exportador para conservar restricciones no diferibles. No se cambia DBML lógico ni migraciones aplicadas. Privilegios son responsabilidad de bootstrap/migraciones; no se exportan desde DBML. BUG003 resuelto solo en generación documental; cotejo con DB viva pendiente.
